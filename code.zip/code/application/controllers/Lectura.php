<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lectura extends CI_Controller {
	public function __construct() {
    parent::__construct();
    $this->load->helper('url');
    $this->load->model("Banco_model");

}

	public function index()
	{
		//$datos["minombre"]=$_GET["minombre"];
		$datos["Nombre"]= "Kattya";
		$datos["Apellido"]= "Torrez";
		$this->load->model("Banco_model");
		$filas = $this->Banco_model->personas();
		$datos["filas"]=$filas;
		$this->load->view('view_lectura', $datos);

	}
	public function eliminar($id_persona){
		$eliminar = $this->Banco_model->eliminar($id_persona);
	}
}
