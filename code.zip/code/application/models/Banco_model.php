<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Banco_model extends CI_model
{
	
	public function __construct()
	{
		parent::__construct();
		}
	public function personas(){
		$this->load->database();
		$query=$this->db->query("select cuentas_bancarias.*, personas.* from cuentas_bancarias inner join personas on cuentas_bancarias.id_persona = personas.id_persona where personas.activo=1");
		return $query->result();
	}
	public function eliminar($id) {
        $this->load->database();
    	$query = $this->db->query("update personas set activo = 0 where id_persona = $id");
    }
}